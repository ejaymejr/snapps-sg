<?php
//HTML2PDF by Cl�ment Lavoillotte

include_once('html2pdf.php');

if(isset($html))
{
	$pdf=new PDF();
	$pdf->Open();
	$pdf->SetCreator("HTML2PDF");
	$pdf->SetTitle($title);
	$pdf->SetSubject($subject);
	$pdf->SetAuthor($author);
	$pdf->SetFont('Arial','',12);
	$pdf->AddPage();
	if(ini_get('magic_quotes_gpc')=='1')
		$html=stripslashes($html);
	$pdf->WriteHTML($html);
	//save and redirect
	$pdf->Output('test.pdf');
	header('Location: test.pdf');
	exit;
}
?>
<html><head><title>HTML2PDF</title>
<style>
INPUT,TEXTAREA,SELECT {
	font-family: lucida console;
	font-size: 8pt;
	border: 1px solid #E0E0E0;
	background-color: #F0F0F0;
	SCROLLBAR-FACE-COLOR: #b9b9b9;
	SCROLLBAR-HIGHLIGHT-COLOR: #b9b9b9;
	SCROLLBAR-SHADOW-COLOR: #b9b9b9;
	SCROLLBAR-3DLIGHT-COLOR: #b9b9b9;
	SCROLLBAR-DARKSHADOW-COLOR: #b9b9b9;
	SCROLLBAR-ARROW-COLOR: #F0F0F0;
	SCROLLBAR-TRACK-COLOR: #F0F0F0;
	SCROLLBAR-BASE-COLOR: #F0F0F0;
}
BODY {
	font-family: lucida console;
	font-size: 8pt;
	background-color: #F0F0F0;
	SCROLLBAR-FACE-COLOR: #b9b9b9;
	SCROLLBAR-HIGHLIGHT-COLOR: #b9b9b9;
	SCROLLBAR-SHADOW-COLOR: #b9b9b9;
	SCROLLBAR-3DLIGHT-COLOR: #b9b9b9;
	SCROLLBAR-DARKSHADOW-COLOR: #b9b9b9;
	SCROLLBAR-ARROW-COLOR: #F0F0F0;
	SCROLLBAR-TRACK-COLOR: #F0F0F0;
	SCROLLBAR-BASE-COLOR: #F0F0F0;
}
</style>
</head><body>
<h1>HTML2PDF</h1>
<div style="border: 1px solid black;">
Supported tags are the following:
<ul type="square">
<li>&lt;br&gt; and &lt;p&gt;</li>
<li>&lt;b&gt;, &lt;i&gt; and &lt;u&gt;</li>
<li>&lt;img&gt; (src and width (or height) are mandatory)</li>
<li>&lt;a&gt; (href is mandatory)</li>
<li>&lt;font&gt;: possible attributes are
<ul><li>color: hex color code</li>
<li>face: available fonts are: arial, times, courier, helvetica, symbol</li></ul>
</li></ul>
To display these tags without interpreting them, use &amp;lt; and &amp;gt;</div>
<form name="pdfgen" method="post" action="<?php echo $PHP_SELF; ?>" target="_blank">
Title :<input type="text" maxlength="30" name="title"><br>
Subject :<input type="text" maxlength="30" name="subject"><br>
Author :<input type="text" maxlength="30" name="author"><br>
Content:<br>
<textarea name="html" cols="50" rows="15"></textarea><br>
<input type="submit" value="Generate PDF">
</form>
</body></html>
